.class public final synthetic Lcom/chimeranft/core/ChimeraProfileActivity$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    invoke-static {p1}, Lcom/chimeranft/core/ChimeraProfileActivity;->$r8$lambda$rt8XHDnvDWLfBGGJ5hKT3_F39sE(Z)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method
