.class public final synthetic Lcom/chimeranft/core/IosSelection$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/chimeranft/core/IosSelection$$ExternalSyntheticLambda4;->f$0:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    iget-object v0, p0, Lcom/chimeranft/core/IosSelection$$ExternalSyntheticLambda4;->f$0:Ljava/lang/Object;

    invoke-static {v0}, Lcom/chimeranft/core/IosSelection;->$r8$lambda$RsUGAuPNWWGqhWMx0KktpFNSXtg(Ljava/lang/Object;)V

    return-void
.end method
